#include "real_epuck_accelerometer_sensor.h"
#include <argos3/core/utility/logging/argos_log.h>

namespace argos {

   /****************************************/
   /****************************************/

   void CRealEPuckAccelerometerSensor::UpdateValues() {
      /* Not implemented */
   }

   /****************************************/
   /****************************************/

}
